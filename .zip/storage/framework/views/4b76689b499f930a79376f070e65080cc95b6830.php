<?php $__env->startSection('content'); ?>
    <div class="roles-permissions">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h2 class="text-gray-700 uppercase font-bold">Assessment</h2>
            </div>
        </div>
        <div class="table w-full mt-8 bg-white rounded">
            <form method="POST" class="w-full max-w-xl px-6 py-12" enctype="multipart/form-data">
                <label class=" alert alert-success block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4">
                    <?php if(session()->has('res')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('res')); ?>

                        </div>
                    <?php endif; ?>
                </label>
                <br>
                <?php echo csrf_field(); ?>
                <div class="md:flex md:items-center mb-6">
                    <label class=" alert alert-success block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4">
                        <?php if(session()->has('res')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('res')); ?>

                            </div>
                        <?php endif; ?>
                    </label>
                </div>
                <div class="md:flex md:items-center mb-6">
                    <div class="md:w-1/3">
                        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4">
                            Class
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <select name="class_id" id="class" required
                                class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-500">
                            <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($value['id']==$id): ?>
                                    <option value="<?php echo e($value['id']); ?>"><?php echo e($value['class_name']); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="md:flex md:items-center mb-6">
                    <div class="md:w-1/3">
                        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4">
                            Subjects
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <select name="subject_id" required id="subject"
                                class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-500">
                            <option value="" disabled selected>--Select--</option>
                            <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1=>$value1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value1['id']); ?>"
                                        data-value="<?php echo e($value1['teacher_id']); ?>"><?php echo e($value1['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="md:flex md:items-center mb-6">
                    <div class="md:w-1/3">
                        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4">
                            Date
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input name="date" id="datepicker-se" autocomplete="off"
                               class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-500"
                               type="text">
                    </div>
                </div>

                <div class="md:flex md:items-center mb-6">
                    <div class="md:w-1/3">
                        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4">
                            Name
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input name="name" autocomplete="off"
                               class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-500"
                               type="text">
                    </div>
                </div>
                <div class="md:flex md:items-center mb-6">
                    <div class="md:w-1/3">
                        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4">
                            Total Marks
                        </label>
                    </div>
                    <div class="md:w-2/3">
                        <input name="total" autocomplete="off"
                               class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-blue-500"
                               type="number">
                    </div>
                </div>
                <div class="md:flex md:items-center">
                    <div class="md:w-1/3"></div>
                    <div class="md:w-2/3">
                        <button
                            class="shadow bg-blue-500 hover:bg-blue-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded"
                            type="submit">
                            Add Assessment
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script>
        $(document).ready(function () {
            $(function () {
                $("#datepicker-se").datepicker(
                    {
                        beforeShowDay: function (date) {
                            var day = date.getDay();
                            return [(day != 0), ''];
                        }
                    });
            })
        })
    </script>
    <script>
        $('form').submit(function (event) {
            event.preventDefault();

            var data = new FormData($(this)[0]);
            $.ajax({
                url: "<?php echo e(route('assessment.addassessmentrequest')); ?>",
                type: 'POST',
                data: data,
                processData: false,
                contentType: false,
                success: function (data) {
                    if (data != 'success') {
                        window.location = "<?php echo e(route('assessment.viewassessments',$id)); ?>"
                    } else {
                        $('form')[0].reset();
                    }
                }
            })
        })

    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel-school-management-system\resources\views/backend/assessment/create.blade.php ENDPATH**/ ?>