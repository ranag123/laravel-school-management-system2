<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Chairity extends Model
{
    protected $guarded = [];
}
